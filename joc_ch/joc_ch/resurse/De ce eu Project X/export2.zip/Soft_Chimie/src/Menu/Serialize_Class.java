package Menu;

public class Serialize_Class {

}
